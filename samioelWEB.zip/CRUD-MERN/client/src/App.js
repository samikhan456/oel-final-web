import './App.css';
import React, {useEffect} from "react"
import Axios  from 'axios';

function App() {

  const [carName,setCarName]= React.useState("");
  const [days,setDays]=React.useState(0);
  const [carList,setCarList]=React.useState([]);
  const [newCarName,setNewCarName]= React.useState("");
  
  useEffect(()=>{
    Axios.get("http://localhost:3001/read").then(response =>{
      setCarList(response.data);
    })
  })


  const addTolist=()=>{
    Axios.post('http://localhost:3001/insert',{carName:carName,days:days})
  }

  const updatecar=(id)=>{
    Axios.put("http://localhost:3001/update",{id:id,newCarName:newCarName})
  }

  const deletecar=(id)=>{
    Axios.delete(`http://localhost:3001/delete/${id}`)
  }
  return (
      <div className='App'>
        <h1>CAR DATABASE</h1>
        <label>Car Name:</label>
        <input type="text" onChange={(event)=>{
          setCarName(event.target.value);
        }} />
        <br></br>
        <br></br>
        <label>EngineCC</label>
        <input type="number" onChange={(event)=>{
          setDays(event.target.value);
        }}  />
        <br></br>
        <br></br>
        <button onClick={addTolist}>Save</button>
        <hr/>
        {
          carList.map((val, key)=>{
            return <div key={key}> 
              <h1>{val.carName}</h1>
              <h1>{val.daysSinceIAte}</h1>
              <input type="text" placeholder='new Car..'  onChange={(event)=>{
          setNewCarName(event.target.value);
        }} />
              <button onClick={()=>updatecar(val._id)}>Update</button>
              <button onClick={()=>deletecar(val._id)}>Delete</button>
            </div>
          })
        }
        </div>
    );
}

export default App;
