const mongoose= require('mongoose');

const CarSchema= new mongoose.Schema({
    carName:{
        type:String,
        required: true,
    },
    daysSinceIAte:{
        type:Number,
        required:true,
    }
});

const Car = mongoose.model("car",CarSchema)
module.exports=Car;